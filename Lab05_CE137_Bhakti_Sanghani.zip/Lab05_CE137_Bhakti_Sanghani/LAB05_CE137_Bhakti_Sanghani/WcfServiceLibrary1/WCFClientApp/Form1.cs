﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCFClientApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new WCFClientApp.ServiceReference1.Service1Client("NetTcpBinding_IService1");
            textBox1.Text = client.GetData(123);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client client = new WCFClientApp.ServiceReference1.Service1Client("NetTcpBinding_IService1");
            int val1 = int.Parse(textBox2.Text);
            int val2 = int.Parse(textBox3.Text);

            label3.Text = client.Multiply(val1, val2).ToString();
        }
    }
}
