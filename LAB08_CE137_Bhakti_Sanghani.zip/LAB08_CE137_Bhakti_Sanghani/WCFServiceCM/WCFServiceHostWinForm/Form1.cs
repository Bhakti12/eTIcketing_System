﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCFServiceHostWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ServiceHost sh = null;
        private void Form1_Load(object sender, EventArgs e)
        {
            Thread th = new Thread(new ThreadStart(hostItThread));
            try {
                th.Start();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            label1.Text = "Service Running";
            th.Join();
        }
        private void hostItThread()
        {
            Uri baseUrl = new Uri("http://localhost:8000/HelloService");
            sh = new ServiceHost(typeof(WCFServiceCM.HelloClass), baseUrl);
            sh.AddServiceEndpoint(typeof(WCFServiceCM.IHelloService), new WSHttpBinding(), "");
            ServiceMetadataBehavior mbehave = new ServiceMetadataBehavior();
            mbehave.HttpGetEnabled = true;
            sh.Description.Behaviors.Add(mbehave);
            sh.Open();
        }
    }
}
