﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace EmployeeLibrary
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public Employee GetEmployee(int id)
        {
            SqlConnection cnn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;
                                Initial Catalog=northwind;
                                Integrated Security=True;
                                Connect Timeout=30;Encrypt=False;
                                TrustServerCertificate=False;
                                ApplicationIntent=ReadWrite;
                                MultiSubnetFailover=False");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandText = "SELECT * FROM employees WHERE emoloyeeid = @id";
            SqlParameter p = new SqlParameter("@id", id);
            cmd.Parameters.Add(p);
            cnn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            Employee emp = new Employee();
            while (reader.Read()) {
                emp.EmployeeID = reader.GetInt32(0);
                emp.FirstName = reader.GetString(1);
                emp.LastName = reader.GetString(2);
            }
            reader.Close();
            cnn.Close();
            return emp;
        }

        public DataSet GetEmployees()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM employees",
                @"Data Source=(localdb)\MSSQLLocalDB;
                Initial Catalog=northwind;Integrated Security=True;
                Connect Timeout=30;Encrypt=False;
                TrustServerCertificate=False;
                ApplicationIntent=ReadWrite;
                MultiSubnetFailover=False");
            DataSet ds = new DataSet();
            da.Fill(ds, "employees");
            return ds;

        }
    }
}
