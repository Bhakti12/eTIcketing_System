﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmployeeClient.ServiceReference1.Service1Client proxy = new
                EmployeeClient.ServiceReference1.Service1Client("BasicHttpBinding_IService1");
            DataSet ds = proxy.GetEmployees();
            listBox1.DataSource = ds.Tables[0].DefaultView;
            listBox1.DisplayMember = "FirstName";
            listBox1.ValueMember = "EmoloyeeID";
            proxy.Close();
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            EmployeeClient.ServiceReference1.Service1Client proxy = new
                EmployeeClient.ServiceReference1.Service1Client("BasicHttpBinding_IService1");
            EmployeeClient.ServiceReference1.Employee emp = proxy.GetEmployee(int.Parse(listBox1.SelectedValue.ToString()));
            label6.Text = emp.EmployeeID.ToString();
            label7.Text = emp.FirstName;
            label8.Text = emp.LastName;
            proxy.Close();
        }
    }
}
